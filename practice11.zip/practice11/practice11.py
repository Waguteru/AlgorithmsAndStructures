import tkinter as tk
import requests
import json

def fetch_repository_info():
    repo_name = entry.get().strip()
    if repo_name:
        url = f"https://api.github.com/repos/{repo_name}"
        response = requests.get(url)

        if response.status_code == 200:
            repo_data = response.json()
            result = {
                'company': None,
                'created_at': repo_data.get('created_at'),
                'email': None,
                'id': repo_data.get('id'),
                'name': repo_data.get('name'),
                'url': repo_data.get('owner', {}).get('url'),
                'description': repo_data.get('description'),
                'homepage': repo_data.get('homepage')
            }
            save_to_file(result)
            output_label.config(text="Информация сохранена в файл.")
        else:
            output_label.config(text="Ошибка: Репозиторий не найден.")
    else:
        output_label.config(text="Пожалуйста, введите имя репозитория.")

def save_to_file(data):
    with open('repository_info.txt', 'w') as file:
        json.dump(data, file, indent=4)

# Создание интерфейса
root = tk.Tk()
root.title("Средство получения информации о репозитории GitHub")

label = tk.Label(root, text="Введите имя репозитория (owner/repo):")
label.pack(pady=10)

entry = tk.Entry(root, width=50)
entry.pack(pady=5)

fetch_button = tk.Button(root, text="Получить информацию", command=fetch_repository_info)
fetch_button.pack(pady=10)

output_label = tk.Label(root, text="")
output_label.pack(pady=10)

root.mainloop()
